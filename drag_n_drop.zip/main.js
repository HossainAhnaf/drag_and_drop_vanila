class UseHorizontalDragableList {
  constructor(element) {
    this.listContainer = element;

    this.isTouchDevice = ('ontouchstart' in window) ||
    (navigator.maxTouchPoints > 0) ||
    (navigator.msMaxTouchPoints > 0);
    
    this.dragStartEventName = this.isTouchDevice ? "touchstart" : "mousedown"
    this.dragMoveHandlerName = this.isTouchDevice ? "touchmove" : "mousemove"
    this.dragEndEventName = this.isTouchDevice ? "touchend" : "mouseup"
   
    this.draggableElements = Array.from(this.listContainer.querySelectorAll('.draggable'))
    this.init()
  }
  init() {
    this.draggableElements.forEach((item) => {
      
      item.setAttribute("draggable", "false");
      item.addEventListener(this.dragStartEventName, this.#dragStartHandler.bind(this))
      item.addEventListener(this.dragEndEventName, this.#dragEndHandler.bind(this))
      if (!this.isTouchDevice) {
        item.addEventListener("mouseleave", this.#dragEndHandler.bind(this))
      }
    })
  }
  #updateNextPrevElement(draggingElement) {
    const draggingElementIndex = this.draggableElements.indexOf(draggingElement)
    this.nextElement = this.draggableElements[draggingElementIndex + 1]
    this.prevElement = this.draggableElements[draggingElementIndex - 1]
  }
  #dragStartHandler(e) {
    this.#updateNextPrevElement(e.currentTarget)
    const draggingElmStartRect = e.currentTarget.getBoundingClientRect()
    const nextElmRect = this.nextElement ? this.nextElement.getBoundingClientRect() : null
    const prevElmRect = this.prevElement ? this.prevElement.getBoundingClientRect() : null
    const startYOffset = this.isTouchDevice ? e.touches[0].clientY : e.clientY

    e.currentTarget.setAttribute("data-dragging", "true");
    e.currentTarget.addEventListener(this.dragMoveHandlerName, (e) => this.#dragMoveHandler(e, startYOffset,draggingElmStartRect, nextElmRect, prevElmRect))
  }
  #dragMoveHandler(e, startYOffset,draggingElmStartRect, nextElmRect, prevElmRect) {
   console.clear()
    const clientY = this.isTouchDevice ? e.touches[0].clientY : e.clientY
    const draggingElmRect = e.currentTarget.getBoundingClientRect()
    console.log(this.nextElement.textContent,this.prevElement)

    if (e.currentTarget.getAttribute("data-dragging") == "true") {
      e.currentTarget.style.setProperty("transform",`translateY(${(clientY - startYOffset)}px)`)
     const isPrevElementDraggedOver = (this.prevElement && draggingElmRect.top <= prevElmRect.top + prevElmRect.height / 2)
      const isNextElementDraggedOver = (this.nextElement && draggingElmRect.top >= nextElmRect.top - nextElmRect.height / 2)
      if (isPrevElementDraggedOver || isNextElementDraggedOver){
       this.#dragOverHandler(e.currentTarget,isPrevElementDraggedOver ? this.prevElement : this.nextElement,isPrevElementDraggedOver ? prevElmRect : nextElmRect,draggingElmStartRect)
      }
    }
  }
  #dragOverHandler(draggingElement, dragOverElement,dragOverElmRect,draggingElmStartRect){
    const draggingElementIndex = this.draggableElements.indexOf(draggingElement)
    dragOverElement.classList.add("drag-over")
    dragOverElement.style.setProperty("transform",`translateY(${(draggingElmStartRect.top - dragOverElmRect.top)}px)`)
    
    if (this.draggableElements[draggingElementIndex - 1] === dragOverElement){
     [this.draggableElements[draggingElementIndex], this.draggableElements[draggingElementIndex - 1] ] = [this.draggableElements[draggingElementIndex - 1] , this.draggableElements[draggingElementIndex]]
    }else{
      [this.draggableElements[draggingElementIndex], this.draggableElements[draggingElementIndex + 1] ] = [this.draggableElements[draggingElementIndex + 1] , this.draggableElements[draggingElementIndex]]
    }
    this.#updateNextPrevElement(draggingElement)
   setTimeout(() => {
    dragOverElement.classList.remove("drag-over")
     
   },333)
  }
  #dragEndHandler({ currentTarget }) {
    currentTarget.setAttribute("data-dragging", "false");
    currentTarget.removeEventListener("mousemove", this.#dragMoveHandler)
  }
  
  
}